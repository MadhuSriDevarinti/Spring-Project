package com.example.animal.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.animal.dao.Animal;
import com.example.animal.service.service;

@RestController
public class controller {

	@Autowired
	private final service ServiceClass;
	
	public controller(service Service)
	{
		this.ServiceClass=Service;
	}
	
	@GetMapping("/getId/{id}")
	public Map<String,Object> getId(@PathVariable(value="id") int id){
		return ServiceClass.getId(id);	
	}
	
	@GetMapping("/getAll")
	public List<Map<String,Object>> getAll(){
		return ServiceClass.getAll();
	}
	
	@GetMapping("/Insert")
	public void Insert(Animal animal){
		ServiceClass.Insert(animal);
	}
	@PostMapping("/Insert")
	public int insertanimal(@RequestBody Animal a) {
		return ServiceClass.Insert(a);
		
	}
	
	@GetMapping("/Update")
	public void Update(Animal animal){
		ServiceClass.Update(animal);
	}
	
	@PostMapping("/Update")
	public int updateanimal(@RequestBody Animal a) {
		return ServiceClass.Update(a);
		
	}
	@GetMapping("/Delete/{id}")
	public int Delete(Animal animal){
		return ServiceClass.Delete(animal) ;
	}
	@DeleteMapping("/Delete/{id}")
	public int Deleteanimal(Animal animal){
		return ServiceClass.Delete(animal) ;
	}
}

